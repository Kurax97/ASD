---------------
 tp-bloom
---------------


.. toctree::
   :maxdepth: 1

   bloomfilter.rst

~~~~~~~~~~
Etat du TP
~~~~~~~~~~

Fini.

Binôme : 
	- Benlamlih Mohammed
	- Abdesselam Lyes

Question 4.2.3
--------------

On a détecté un faux positif pour n = 2**4


Question 4.3.4
--------------

.. image:: ../images/tp4.png
   :height: 100px
   :width: 200 px
   :scale: 50 %
   :alt: Graph des 3 stratégies pour m = 10
   :align: right


On remarque que plus la taille du filtre est petite, plus on a un pourcentage de faux positifs élevé.
Et inversement plus la taille du filtre est grande, plus on a un pourcentage de faux positifs petit.


Fin.